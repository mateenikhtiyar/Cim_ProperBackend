import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  UseGuards,
  Request,
  ForbiddenException,
} from "@nestjs/common"
import { ApiBearerAuth, ApiOperation, ApiResponse, ApiTags, ApiParam } from "@nestjs/swagger"
import { JwtAuthGuard } from "../auth/guards/jwt-auth.guard"
import { RolesGuard } from "../guards/roles.guard"
import { Roles } from "../decorators/roles.decorator"
import { DealsService } from "./deals.service"
import { CreateDealDto } from "./dto/create-deal.dto"
import { UpdateDealDto } from "./dto/update-deal.dto"
import { DealResponseDto } from "./dto/deal-response.dto"
import { UnauthorizedException } from "@nestjs/common"

interface RequestWithUser extends Request {
  user: {
    userId: string
    email: string
    role: string
  }
}

@ApiTags("deals")
@Controller("deals")
export class DealsController {
  constructor(private readonly dealsService: DealsService) { }

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles("seller")
  @Post()
  @ApiBearerAuth()
  @ApiOperation({ summary: "Create a new deal" })
  @ApiResponse({ status: 201, description: "Deal created successfully", type: DealResponseDto })
  @ApiResponse({ status: 403, description: "Forbidden - requires seller role" })
  async create(@Body() createDealDto: CreateDealDto, @Request() req: RequestWithUser) {
    if (!req.user?.userId) {
      throw new UnauthorizedException("User not authenticated");
    }
    return this.dealsService.create(req.user.userId, createDealDto)
  }

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles("admin")
  @Get("admin")
  @ApiBearerAuth()
  @ApiOperation({ summary: "Get all deals (admin only)" })
  @ApiResponse({ status: 200, description: "Return all deals", type: [DealResponseDto] })
  @ApiResponse({ status: 403, description: "Forbidden - requires admin role" })
  async findAllAdmin() {
    return this.dealsService.findAll()
  }

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles("seller")
  @Get("my-deals")
  @ApiBearerAuth()
  @ApiOperation({ summary: "Get all deals created by the seller" })
  @ApiResponse({ status: 200, description: "Return seller's deals", type: [DealResponseDto] })
  @ApiResponse({ status: 403, description: "Forbidden - requires seller role" })
  async findMine(@Request() req: RequestWithUser) {
    if (!req.user?.userId) {
      throw new UnauthorizedException("User not authenticated");
    }
    return this.dealsService.findBySeller(req.user.userId);
  }

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles("buyer")
  @Get("available")
  @ApiBearerAuth()
  @ApiOperation({ summary: "Get all deals available to the buyer" })
  @ApiResponse({ status: 200, description: "Return available deals", type: [DealResponseDto] })
  @ApiResponse({ status: 403, description: "Forbidden - requires buyer role" })
  async findAvailableForBuyer(@Request() req: RequestWithUser) {
    if (!req.user?.userId) {
      throw new UnauthorizedException("User not authenticated");
    }
    return this.dealsService.findDealsForBuyer(req.user.userId);
  }

  @Get("public")
  @ApiOperation({ summary: "Get all public active deals" })
  @ApiResponse({ status: 200, description: "Return public deals", type: [DealResponseDto] })
  async findPublic() {
    return this.dealsService.findPublicDeals()
  }

  @UseGuards(JwtAuthGuard)
  @Get(":id")
  @ApiBearerAuth()
  @ApiOperation({ summary: "Get a deal by ID" })
  @ApiParam({ name: "id", description: "Deal ID" })
  @ApiResponse({ status: 200, description: "Return the deal", type: DealResponseDto })
  @ApiResponse({ status: 404, description: "Deal not found" })
  async findOne(@Param("id") id: string, @Request() req: RequestWithUser) {
    if (!req.user?.userId) {
      throw new UnauthorizedException("User not authenticated");
    }
    const deal = await this.dealsService.findOne(id)
    const userRole = req.user.role
    const userId = req.user.userId

    if (
      userRole === "admin" ||
      (userRole === "seller" && deal.seller.toString() === userId) ||
      (userRole === "buyer" &&
        (deal.isPublic || deal.targetedBuyers.includes(userId) || deal.interestedBuyers.includes(userId)))
    ) {
      return deal
    }

    throw new ForbiddenException("You don't have permission to access this deal")
  }

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles("seller")
  @Patch(":id")
  @ApiBearerAuth()
  @ApiOperation({ summary: "Update a deal" })
  @ApiParam({ name: "id", description: "Deal ID" })
  @ApiResponse({ status: 200, description: "Deal updated successfully", type: DealResponseDto })
  @ApiResponse({ status: 403, description: "Forbidden - requires seller role and ownership" })
  @ApiResponse({ status: 404, description: "Deal not found" })
  async update(@Param("id") id: string, @Request() req: RequestWithUser, @Body() updateDealDto: UpdateDealDto) {
    if (!req.user?.userId) {
      throw new UnauthorizedException("User not authenticated");
    }
    return this.dealsService.update(id, req.user.userId, updateDealDto)
  }

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles("admin")
  @Patch("admin/:id")
  @ApiBearerAuth()
  @ApiOperation({ summary: "Update a deal (admin only)" })
  @ApiParam({ name: "id", description: "Deal ID" })
  @ApiResponse({ status: 200, description: "Deal updated successfully", type: DealResponseDto })
  @ApiResponse({ status: 403, description: "Forbidden - requires admin role" })
  @ApiResponse({ status: 404, description: "Deal not found" })
  async updateByAdmin(@Param("id") id: string, @Body() updateDealDto: UpdateDealDto) {
    return this.dealsService.updateByAdmin(id, updateDealDto)
  }

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles("seller")
  @Delete(":id")
  @ApiBearerAuth()
  @ApiOperation({ summary: "Delete a deal" })
  @ApiParam({ name: "id", description: "Deal ID" })
  @ApiResponse({ status: 200, description: "Deal deleted successfully" })
  @ApiResponse({ status: 403, description: "Forbidden - requires seller role and ownership" })
  @ApiResponse({ status: 404, description: "Deal not found" })
  async remove(@Param("id") id: string, @Request() req: RequestWithUser) {
    if (!req.user?.userId) {
      throw new UnauthorizedException("User not authenticated");
    }
    await this.dealsService.remove(id, req.user.userId)
    return { message: "Deal deleted successfully" }
  }

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles("admin")
  @Delete("admin/:id")
  @ApiBearerAuth()
  @ApiOperation({ summary: "Delete a deal (admin only)" })
  @ApiParam({ name: "id", description: "Deal ID" })
  @ApiResponse({ status: 200, description: "Deal deleted successfully" })
  @ApiResponse({ status: 403, description: "Forbidden - requires admin role" })
  @ApiResponse({ status: 404, description: "Deal not found" })
  async removeByAdmin(@Param("id") id: string) {
    await this.dealsService.removeByAdmin(id);
    return { message: "Deal deleted successfully" };
  }

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles("buyer")
  @Post(":id/interest")
  @ApiBearerAuth()
  @ApiOperation({ summary: "Express interest in a deal" })
  @ApiParam({ name: "id", description: "Deal ID" })
  @ApiResponse({ status: 200, description: "Interest registered successfully", type: DealResponseDto })
  @ApiResponse({ status: 403, description: "Forbidden - requires buyer role" })
  @ApiResponse({ status: 404, description: "Deal not found" })
  async expressInterest(@Param("id") id: string, @Request() req: RequestWithUser) {
    if (!req.user?.userId) {
      throw new UnauthorizedException("User not authenticated");
    }
    return this.dealsService.addInterestedBuyer(id, req.user.userId)
  }

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles("buyer")
  @Delete(":id/interest")
  @ApiBearerAuth()
  @ApiOperation({ summary: "Remove interest in a deal" })
  @ApiParam({ name: "id", description: "Deal ID" })
  @ApiResponse({ status: 200, description: "Interest removed successfully", type: DealResponseDto })
  @ApiResponse({ status: 403, description: "Forbidden - requires buyer role" })
  @ApiResponse({ status: 404, description: "Deal not found" })
  async removeInterest(@Param("id") id: string, @Request() req: RequestWithUser) {
    if (!req.user?.userId) {
      throw new UnauthorizedException("User not authenticated");
    }
    return this.dealsService.removeInterestedBuyer(id, req.user.userId)
  }

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles("seller")
  @Post(":id/publish")
  @ApiBearerAuth()
  @ApiOperation({ summary: "Publish a deal" })
  @ApiParam({ name: "id", description: "Deal ID" })
  @ApiResponse({ status: 200, description: "Deal published successfully", type: DealResponseDto })
  @ApiResponse({ status: 403, description: "Forbidden - requires seller role and ownership" })
  @ApiResponse({ status: 404, description: "Deal not found" })
  async publishDeal(@Param("id") id: string, @Request() req: RequestWithUser) {
    if (!req.user?.userId) {
      throw new UnauthorizedException("User not authenticated");
    }
    return this.dealsService.publishDeal(id, req.user.userId)
  }

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles("seller")
  @Post(":id/complete")
  @ApiBearerAuth()
  @ApiOperation({ summary: "Mark a deal as completed" })
  @ApiParam({ name: "id", description: "Deal ID" })
  @ApiResponse({ status: 200, description: "Deal marked as completed", type: DealResponseDto })
  @ApiResponse({ status: 403, description: "Forbidden - requires seller role and ownership" })
  @ApiResponse({ status: 404, description: "Deal not found" })
  async completeDeal(
    @Param("id") id: string,
    @Request() req: RequestWithUser,
    @Body() body: { finalSalePrice: number },
  ) {
    if (!req.user?.userId) {
      throw new UnauthorizedException("User not authenticated");
    }
    return this.dealsService.completeDeal(id, req.user.userId, body.finalSalePrice)
  }
}