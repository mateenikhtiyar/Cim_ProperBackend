import { Injectable, NotFoundException, ForbiddenException } from "@nestjs/common"
import { InjectModel } from "@nestjs/mongoose"
import { Model } from "mongoose"
import { Deal, type DealDocument, DealStatus } from "./schemas/deal.schema"
import { CreateDealDto } from "./dto/create-deal.dto"
import { UpdateDealDto } from "./dto/update-deal.dto"

@Injectable()
export class DealsService {
  constructor(
    @InjectModel(Deal.name)
    private dealModel: Model<DealDocument>,
  ) { }

  async create(sellerId: string, createDealDto: CreateDealDto): Promise<Deal> {
    const newDeal = new this.dealModel({
      ...createDealDto,
      seller: sellerId,
      status: createDealDto.status || DealStatus.DRAFT,
      timeline: {
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    })

    return newDeal.save()
  }

  async findAll(query: any = {}): Promise<Deal[]> {
    return this.dealModel.find(query).exec()
  }

  async findBySeller(sellerId: string): Promise<Deal[]> {
    return this.dealModel.find({ seller: sellerId }).exec()
  }

  async findOne(id: string): Promise<Deal> {
    const deal = await this.dealModel.findById(id).exec()
    if (!deal) {
      throw new NotFoundException(`Deal with ID ${id} not found`)
    }
    return deal
  }

  async findPublicDeals(): Promise<Deal[]> {
    return this.dealModel
      .find({
        isPublic: true,
        status: DealStatus.ACTIVE,
      })
      .exec()
  }

  async findDealsForBuyer(buyerId: string): Promise<Deal[]> {
    return this.dealModel
      .find({
        $or: [
          { isPublic: true, status: DealStatus.ACTIVE },
          { targetedBuyers: buyerId, status: DealStatus.ACTIVE },
          { interestedBuyers: buyerId },
        ],
      })
      .exec()
  }

  async update(id: string, sellerId: string, updateDealDto: UpdateDealDto): Promise<Deal> {
    const deal = await this.dealModel.findById(id).exec()

    if (!deal) {
      throw new NotFoundException(`Deal with ID ${id} not found`)
    }

    // Verify that the seller owns this deal
    if (deal.seller.toString() !== sellerId) {
      throw new ForbiddenException("You don't have permission to update this deal")
    }

    // Check if we're changing status to ACTIVE and update publishedAt timestamp
    if (updateDealDto.status === DealStatus.ACTIVE && deal.status !== DealStatus.ACTIVE) {
      deal.timeline.publishedAt = new Date()
    }

    // Check if we're changing status to COMPLETED and update completedAt timestamp
    if (updateDealDto.status === DealStatus.COMPLETED && deal.status !== DealStatus.COMPLETED) {
      deal.timeline.completedAt = new Date()
    }

    // If finalSalePrice is provided and deal is being completed, add it to financialDetails
    if (updateDealDto.finalSalePrice && updateDealDto.status === DealStatus.COMPLETED) {
      deal.financialDetails.finalSalePrice = updateDealDto.finalSalePrice
      // Remove finalSalePrice from the updateDealDto to avoid duplication
      delete updateDealDto.finalSalePrice
    }

    deal.timeline.updatedAt = new Date()

    Object.assign(deal, updateDealDto)
    return deal.save()
  }

  async updateByAdmin(id: string, updateDealDto: UpdateDealDto): Promise<Deal> {
    const deal = await this.dealModel.findById(id).exec()

    if (!deal) {
      throw new NotFoundException(`Deal with ID ${id} not found`)
    }

    // Logic for status changes and timestamps same as update method
    if (updateDealDto.status === DealStatus.ACTIVE && deal.status !== DealStatus.ACTIVE) {
      deal.timeline.publishedAt = new Date()
    }

    if (updateDealDto.status === DealStatus.COMPLETED && deal.status !== DealStatus.COMPLETED) {
      deal.timeline.completedAt = new Date()
    }

    if (updateDealDto.finalSalePrice && updateDealDto.status === DealStatus.COMPLETED) {
      deal.financialDetails.finalSalePrice = updateDealDto.finalSalePrice
      delete updateDealDto.finalSalePrice
    }

    deal.timeline.updatedAt = new Date()

    Object.assign(deal, updateDealDto)
    return deal.save()
  }

  async remove(id: string, sellerId: string): Promise<void> {
    const deal = await this.dealModel.findById(id).exec()

    if (!deal) {
      throw new NotFoundException(`Deal with ID ${id} not found`)
    }

    // Verify that the seller owns this deal
    if (deal.seller.toString() !== sellerId) {
      throw new ForbiddenException("You don't have permission to delete this deal")
    }

    await this.dealModel.findByIdAndDelete(id).exec()
  }

  async removeByAdmin(id: string): Promise<void> {
    const result = await this.dealModel.findByIdAndDelete(id).exec()
    if (!result) {
      throw new NotFoundException(`Deal with ID ${id} not found`)
    }
  }

  async addInterestedBuyer(dealId: string, buyerId: string): Promise<Deal> {
    const deal = await this.dealModel.findById(dealId).exec()

    if (!deal) {
      throw new NotFoundException(`Deal with ID ${dealId} not found`)
    }

    // Only allow interest in ACTIVE deals
    if (deal.status !== DealStatus.ACTIVE) {
      throw new ForbiddenException("This deal is not currently active")
    }

    // Check if buyer is already marked as interested
    if (!deal.interestedBuyers.includes(buyerId)) {
      deal.interestedBuyers.push(buyerId)
      await deal.save()
    }

    return deal
  }

  async removeInterestedBuyer(dealId: string, buyerId: string): Promise<Deal> {
    const deal = await this.dealModel.findById(dealId).exec()

    if (!deal) {
      throw new NotFoundException(`Deal with ID ${dealId} not found`)
    }

    // Remove buyer from interested list
    deal.interestedBuyers = deal.interestedBuyers.filter((id) => id.toString() !== buyerId)

    await deal.save()
    return deal
  }

  async publishDeal(id: string, sellerId: string): Promise<Deal> {
    const deal = await this.dealModel.findById(id).exec()

    if (!deal) {
      throw new NotFoundException(`Deal with ID ${id} not found`)
    }

    // Verify that the seller owns this deal
    if (deal.seller.toString() !== sellerId) {
      throw new ForbiddenException("You don't have permission to publish this deal")
    }

    // Change status to ACTIVE and set publishedAt timestamp
    deal.status = DealStatus.ACTIVE
    deal.timeline.publishedAt = new Date()
    deal.timeline.updatedAt = new Date()

    return deal.save()
  }

  async completeDeal(id: string, sellerId: string, finalSalePrice: number): Promise<Deal> {
    const deal = await this.dealModel.findById(id).exec()

    if (!deal) {
      throw new NotFoundException(`Deal with ID ${id} not found`)
    }

    // Verify that the seller owns this deal
    if (deal.seller.toString() !== sellerId) {
      throw new ForbiddenException("You don't have permission to complete this deal")
    }

    // Change status to COMPLETED and set completedAt timestamp
    deal.status = DealStatus.COMPLETED
    deal.timeline.completedAt = new Date()
    deal.timeline.updatedAt = new Date()
    deal.financialDetails.finalSalePrice = finalSalePrice

    return deal.save()
  }
}
