export class Buyer {}
