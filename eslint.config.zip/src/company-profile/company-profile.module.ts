import { Module } from '@nestjs/common';
import { CompanyProfileService } from './company-profile.service';
import { CompanyProfileController } from './company-profile.controller';
import { SharedModule } from '../shared.module';

@Module({
  imports: [SharedModule],
  controllers: [CompanyProfileController],
  providers: [CompanyProfileService],
  exports: [CompanyProfileService],  // Export the service so it can be used in other modules
})
export class CompanyProfileModule { }