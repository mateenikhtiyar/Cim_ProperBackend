export class CompanyProfile {}
